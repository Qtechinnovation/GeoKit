# GeoKit
GeoKit is just a collection of a couple of little python scripts to help with high school geometry.
